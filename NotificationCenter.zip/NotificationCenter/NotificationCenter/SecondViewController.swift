//
//  SecondViewController.swift
//  NotificationCenter
//
//  Created by SOTSYS027 on 01/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func btnahm(_ sender: Any) {
        NotificationCenter.default.post(name: .exahmdabad, object: nil)
    }
    
    @IBAction func btnsurat(_ sender: Any) {
        NotificationCenter.default.post(name: .exsurat, object: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
