//
//  ViewController.swift
//  NotificationCenter
//
//  Created by SOTSYS027 on 01/02/18.
//  Copyright © 2018 SOTSYS027. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblCity: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        NotificationCenter.default.addObserver(self, selector: #selector(selectAhdabad(notification:)), name: .exahmdabad, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(selectSurat(notification:)), name: .exsurat, object: nil)
    }

    @objc func selectAhdabad(notification: Notification){
        lblCity.text = "Ahmedabad"
    }

   @objc func selectSurat(notification: Notification){
        lblCity.text = "Surat"
    }

}

extension Notification.Name{
   static let exahmdabad = Notification.Name("Ahmedabad")
   static let exsurat = Notification.Name("Surat")
}
